KYNETIX TWO-SENSOR UPDATE

Use one FDC1004 breakout, not a second breakout.
Sensor 1: one copper plate to CIN1, other plate to shared GND.
Sensor 2: one copper plate to CIN2, other plate to shared GND.
ESP32 3V3 -> ProtoCentral 3.3V; leave VCC unused.
ESP32 GPIO21 -> SDA; GPIO22 -> SCL; GND -> GND.
Leave CIN3/4 and SLD1/2 unused. No old RC resistor.

Extract the ZIP. Open Kynetix_Two_Sensors/Kynetix_Two_Sensors.ino.
Use ESP32 Dev Module in Arduino IDE and the USB COM port.
No new libraries or drivers: Wire comes with the ESP32 boards package.
Upload and open Serial Monitor at 115200 baud.
Keep BOTH sensors unloaded at startup; baseline acquisition takes roughly
one second or more. Send b + Enter to re-zero BOTH sensors while unloaded.

Output example: Cap1: 0.12345, Cap 2: -0.00456
Each number is the change from that sensor's own baseline in pF.
No CPU ticks, total-capacitance columns or force conversion are printed.
A value of nan means invalid baseline, communication error or range issue;
it is not zero capacitance. Verify wiring and send b while unloaded to retry.
CAPDAC offsets are adjusted independently during baseline collection and
held fixed during recording. Measurements are sequential, not simultaneous.
Target output rate is 20 paired lines/second, subject to communication delays.
This USB-only sketch replaces the old CSV format; the prior CSV logger is
not compatible with these labeled lines.

Simulated C++ checks passed: separate channels and offsets, signed deltas,
paired output, range failures, missing device, timeout and re-zero.
An actual ESP32 compile/upload and hardware sensor test were not available.
