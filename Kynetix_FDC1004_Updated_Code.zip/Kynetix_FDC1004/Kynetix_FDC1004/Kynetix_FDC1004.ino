// KYNETIX: one copper/silicone capacitor, ProtoCentral FDC1004, original ESP32.
// Wiring: ESP32 3V3 -> breakout 3.3V (VCC unused); GND -> GND;
// GPIO21 -> SDA; GPIO22 -> SCL; top copper -> CIN1; bottom copper -> GND.
// Remove the old RC resistor and GPIO25/26 sensor connections.
// Leave CIN2-4 and SLD1/SLD2 unconnected for this initial test.
// No external FDC1004 library: register access uses built-in Wire.
// USB serial: 115200 baud. Send b + Enter to re-zero with the sensor unloaded.
// Bluetooth Classic SPP: Kynetix; supported by the original ESP32, not iOS.
// cap_pF includes sensor + wiring capacitance; delta_pF is change from baseline.
// This is capacitance measurement, not force calibration or contact detection.
#include <Arduino.h>
#include <Wire.h>
#include <esp_timer.h>
#include <stdarg.h>
#include <math.h>

// ---------------- SETTINGS ----------------
#define ENABLE_BLUETOOTH 1   // Set 0 to disable Bluetooth; USB still works.
const char *BT_NAME = "Kynetix";
const int SDA_PIN = 21;
const int SCL_PIN = 22;
const uint8_t SENSOR_CHANNEL = 0; // 0=CIN1, 1=CIN2, 2=CIN3, 3=CIN4.
const bool PLOT_MODE = false;
const bool CSV_MODE = false;     // Set true for the included Python logger.
const float PLOT_RANGE = 0.2f;   // Guide lines, not a hard limit on the graph.
const int N_SAMPLES = 1;         // New conversions per reading; keep 1 for timing.
const int BASELINE_SAMPLES = 100;
const uint32_t PERIOD_US = PLOT_MODE ? 50000 : (CSV_MODE ? 10000 : 50000);
// Single-shot conversion at 400 S/s (~2.5 ms); CSV targets 100 readings/s.
// Actual rate includes I2C, averaging, serial and Bluetooth overhead.
const uint8_t RATE_CODE = 3;     // 1=100, 2=200, 3=400 S/s.
const uint32_t CONVERSION_TIMEOUT_MS = 50;
// ------------------------------------------
#if ENABLE_BLUETOOTH
#include <BluetoothSerial.h>
#if !defined(CONFIG_BT_SPP_ENABLED)
#error "Bluetooth Classic SPP requires an original ESP32. Set ENABLE_BLUETOOTH to 0 for USB-only operation."
#endif
BluetoothSerial SerialBT;
#endif
static_assert(SENSOR_CHANNEL < 4, "SENSOR_CHANNEL must be 0..3");
static_assert(N_SAMPLES > 0, "N_SAMPLES must be positive");
static_assert(RATE_CODE >= 1 && RATE_CODE <= 3, "RATE_CODE must be 1..3");
const uint8_t FDC_ADDR = 0x50;
const uint8_t REG_CONFIG = 0x0C;
const uint8_t REG_MEAS_CONFIG = 0x08; // Use measurement slot 1 for selected CIN.
const float COUNTS_PER_PF = 524288.0f; // 2^19.
const float CAPDAC_STEP_PF = 3.125f;
uint8_t capdac = 0;
float baselinePF = 0;
bool baselineValid = false;
bool deviceReady = false;
uint32_t lastPrint = 0;

void out(const char *fmt, ...) {
  char buf[320];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf), fmt, args);
  va_end(args);
  Serial.print(buf);
#if ENABLE_BLUETOOTH
  if (SerialBT.hasClient()) SerialBT.print(buf);
#endif
}

// Both bytes are transmitted/read in the order required by the TI datasheet.
bool writeReg(uint8_t reg, uint16_t value) {
  Wire.beginTransmission(FDC_ADDR);
  Wire.write(reg);
  Wire.write((uint8_t)(value >> 8));
  Wire.write((uint8_t)value);
  return Wire.endTransmission() == 0;
}
bool readReg(uint8_t reg, uint16_t &value) {
  Wire.beginTransmission(FDC_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(FDC_ADDR, (uint8_t)2) != 2) return false;
  uint16_t hi = (uint8_t)Wire.read();
  uint16_t lo = (uint8_t)Wire.read();
  value = (hi << 8) | lo;
  return true;
}
bool configureMeasurement() {
  // CHA=selected CIN; CHB=CAPDAC, including when its value is zero.
  uint16_t conf = ((uint16_t)SENSOR_CHANNEL << 13) |
                  (4U << 10) | ((uint16_t)capdac << 5);
  return writeReg(REG_MEAS_CONFIG, conf);
}
int32_t decodeResult(uint16_t msb, uint16_t lsb) {
  uint32_t bits = ((uint32_t)msb << 8) | (lsb >> 8);
  // Explicit signed 24-bit conversion, without shifting a negative integer.
  return (bits & 0x800000U) ? (int32_t)bits - 16777216L : (int32_t)bits;
}
bool readOne(float &residualPF) {
  // REPEAT=0, MEAS_1=1. A new conversion for every call.
  uint16_t trigger = ((uint16_t)RATE_CODE << 10) | 0x0080;
  if (!writeReg(REG_CONFIG, trigger)) return false;
  uint32_t start = millis();
  uint16_t status = 0;
  while (true) {
    if (!readReg(REG_CONFIG, status)) return false;
    if (status & 0x0008) break; // DONE_1.
    if ((uint32_t)(millis() - start) >= CONVERSION_TIMEOUT_MS) return false;
    delay(1); // Yield to ESP32 background tasks; no interrupt disabling.
  }
  uint16_t msb, lsb;
  if (!readReg(0x00, msb) || !readReg(0x01, lsb)) return false;
  // Reading both measurement registers clears DONE_1.
  residualPF = decodeResult(msb, lsb) / COUNTS_PER_PF;
  return true;
}

// Adjust only while re-zeroing. Frozen during acquisition to avoid offset steps.
bool tuneOffset() {
  capdac = 0;
  for (int tries = 0; tries < 64; tries++) {
    if (!configureMeasurement()) return false;
    float residual;
    if (!readOne(residual)) return false;
    if (residual > 4.0f && capdac < 31) { capdac++; continue; }
    if (residual < -4.0f && capdac > 0) { capdac--; continue; }
    return fabsf(residual) < 14.9f;
  }
  return false;
}

void csvHeader() {
  if (CSV_MODE && !PLOT_MODE)
    out("time_s,cap_pF,delta_pF,capdac,errors,status\n");
}
void takeBaseline() {
  baselineValid = false;
  if (!PLOT_MODE) out("Measuring baseline - keep the sensor unloaded...\n");
  if (!tuneOffset()) {
    if (!PLOT_MODE)
      out("ERROR: baseline offset setup failed. Check SDA/SCL, power and sensor range; send b to retry.\n");
    csvHeader();
    return;
  }
  double sum = 0;
  int good = 0, errors = 0;
  for (int i = 0; i < BASELINE_SAMPLES; i++) {
    float residual;
    if (!readOne(residual) || fabsf(residual) >= 14.9f) { errors++; continue; }
    sum += residual + capdac * CAPDAC_STEP_PF;
    good++;
  }
  // Refuse an unreliable baseline instead of treating errors as zero capacitance.
  if (good >= BASELINE_SAMPLES * 8 / 10) {
    baselinePF = sum / good;
    baselineValid = true;
    if (!PLOT_MODE)
      out("Baseline: %.5f pF | CAPDAC=%u | successful=%d/%d | errors=%d\n",
          baselinePF, (unsigned)capdac, good, BASELINE_SAMPLES, errors);
  } else if (!PLOT_MODE) {
    out("ERROR: too few valid baseline readings (%d/%d). Send b to retry.\n",
        good, BASELINE_SAMPLES);
  }
  csvHeader();
}
bool baselineRequested() {
  bool requested = false;
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'b' || c == 'B') requested = true;
  }
#if ENABLE_BLUETOOTH
  while (SerialBT.available()) {
    char c = SerialBT.read();
    if (c == 'b' || c == 'B') requested = true;
  }
#endif
  return requested;
}
bool initializeFDC() {
  uint16_t manufacturer, device;
  if (!readReg(0xFE, manufacturer) || !readReg(0xFF, device)) return false;
  if (manufacturer != 0x5449 || device != 0x1004) return false;
  if (!writeReg(REG_CONFIG, 0x8000)) return false; // Software reset.
  delay(10);
  uint16_t status;
  if (!readReg(REG_CONFIG, status) || (status & 0x8000)) return false;
  return configureMeasurement();
}
void setup() {
  Serial.begin(115200);
  delay(500);
#if ENABLE_BLUETOOTH
  bool btOK = SerialBT.begin(BT_NAME);
#endif
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);
  Wire.setTimeOut(20); // ESP32 Wire transaction timeout in milliseconds.
  if (!PLOT_MODE) {
    out("\n=== KYNETIX sensor: FDC1004 on CIN%u ===\n", (unsigned)SENSOR_CHANNEL + 1);
    out("I2C SDA=%d, SCL=%d, address=0x50; USB baud=115200\n", SDA_PIN, SCL_PIN);
#if ENABLE_BLUETOOTH
    out("Bluetooth: %s (%s)\n", BT_NAME, btOK ? "started" : "failed; USB still works");
#endif
    out("Send b + Enter to re-zero. Keep the sensor unloaded during startup.\n");
  }
  deviceReady = initializeFDC();
  if (deviceReady) takeBaseline();
  else if (!PLOT_MODE) out("ERROR: FDC1004 not found. Check 3.3V, GND, SDA and SCL; send b to retry.\n");
  lastPrint = micros();
}
void loop() {
  if (baselineRequested()) {
    if (!deviceReady) deviceReady = initializeFDC();
    if (deviceReady) takeBaseline();
    else if (!PLOT_MODE) out("ERROR: FDC1004 still not found at 0x50.\n");
    lastPrint = micros();
  }
  if ((uint32_t)(micros() - lastPrint) < PERIOD_US) { delay(1); return; }
  lastPrint = micros(); // No catch-up bursts after overruns or baseline collection.
  const char *status = "OK";
  int errors = 0;
  float capPF = NAN, deltaPF = NAN;
  if (!deviceReady) status = "NO_DEVICE";
  else if (!baselineValid) status = "NO_BASELINE";
  else {
    double sum = 0;
    int good = 0;
    bool saturated = false;
    for (int i = 0; i < N_SAMPLES; i++) {
      float residual;
      if (!readOne(residual)) { errors++; continue; }
      if (fabsf(residual) >= 14.9f) { saturated = true; errors++; continue; }
      sum += residual + capdac * CAPDAC_STEP_PF;
      good++;
    }
    if (saturated) status = "RANGE"; // Drop the entire averaged reading on saturation.
    else if (!good) status = "READ_ERROR";
    else {
      capPF = sum / good;
      deltaPF = capPF - baselinePF;
      if (errors) status = "PARTIAL";
    }
  }
  // esp_timer_get_time is 64-bit, unlike micros(), which wraps after ~71 minutes.
  double t_s = esp_timer_get_time() / 1e6;
  if (PLOT_MODE) {
    out("change_pF:%.5f,top:%.3f,bottom:%.3f,valid:%d\n",
        deltaPF, PLOT_RANGE, -PLOT_RANGE, isfinite(deltaPF) ? 1 : 0);
  } else if (CSV_MODE) {
    out("%.6f,%.5f,%.5f,%u,%d,%s\n", t_s, capPF, deltaPF,
        (unsigned)capdac, errors, status);
  } else if (isfinite(capPF)) {
    out("t=%9.3f s | C=%9.5f pF | change=%+9.5f pF | CAPDAC=%u | errors=%d/%d | %s\n",
        t_s, capPF, deltaPF, (unsigned)capdac, errors, N_SAMPLES, status);
  } else {
    out("t=%9.3f s | %s | errors=%d | check wiring/range; send b while unloaded\n",
        t_s, status, errors);
  }
}
