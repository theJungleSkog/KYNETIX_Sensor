KYNETIX FDC1004 update -- one sensor, original ESP32 Dev Module

FILES
Kynetix_FDC1004/Kynetix_FDC1004.ino: Arduino sketch.
kynetix_fdc1004_logger.py: updated optional computer logger and graph.

WIRING (ProtoCentral V4 board photographed)
ESP32 3V3 -> breakout 3.3V; leave breakout VCC disconnected.
ESP32 GND -> breakout GND (either labeled GND pin).
ESP32 D21 / GPIO21 -> breakout SDA.
ESP32 D22 / GPIO22 -> breakout SCL.
Sensor top copper -> breakout CIN1.
Sensor bottom copper -> shared GND.
Remove the old RC resistor; disconnect sensor from GPIO25 and GPIO26.
Leave other CIN and SLD/SHLD pins unconnected for this first test.
ProtoCentral provides I2C pull-ups; no external ones needed for this board.

ARDUINO IDE
1. Extract this ZIP before opening files.
2. Open Kynetix_FDC1004/Kynetix_FDC1004.ino. Keep its containing folder name.
3. Select Tools > Board > esp32 > ESP32 Dev Module (original ESP32).
4. Select your ESP32 USB COM port under Tools > Port.
5. Upload; hold BOOT when Connecting... appears if needed, then release.
6. Open Serial Monitor at 115200 baud. Keep sensor unloaded at startup.
7. Baseline: ... confirms baseline acquisition. Press the sensor and watch
   change in pF; send b + Enter while unloaded to set a new baseline.

No additional Arduino libraries are needed. Wire and BluetoothSerial are
included in the ESP32 boards package. An FDC1004 library is not required
because this sketch implements its register access directly.
If your previous ESP32 sketch uploaded, keep the same ESP32 board package
and USB driver. The FDC1004 itself has no separate PC driver.
If ESP32 boards are absent: File > Preferences > Additional Boards Manager
URLs: https://espressif.github.io/arduino-esp32/package_esp32_index.json
Then Tools > Board > Boards Manager: install esp32 by Espressif Systems.

MODES -- edit settings at the top, then upload again
Defaults: PLOT_MODE=false, CSV_MODE=false, ENABLE_BLUETOOTH=1, N_SAMPLES=1.
Readable USB/Bluetooth monitor: keep both modes false (~20 readings/s target).
Arduino Serial Plotter: PLOT_MODE=true, CSV_MODE=false (~20 points/s target).
Python logger / CSV: PLOT_MODE=false, CSV_MODE=true (~100 readings/s target).
PLOT_MODE takes priority over CSV_MODE.
PLOT_RANGE adds guide lines; it does not impose a hard graph scale.
ENABLE_BLUETOOTH=0 disables Bluetooth and keeps USB operation.
Do not increase N_SAMPLES for ground-contact timing without considering
extra averaging delay and the reduction in output rate.

BLUETOOTH
Pair a Windows laptop with Kynetix and open its outgoing Bluetooth COM port.
Readings are sent through USB and Bluetooth; either can send b to re-zero.
A new Bluetooth client receives subsequent readings; send b to print a new
baseline/header if desired. The sensor must be unloaded when re-zeroing.
This uses Bluetooth Classic SPP on the original ESP32 in your photos.
It is not an iPhone/iOS BLE connection. Other ESP32 variants without Classic
SPP require ENABLE_BLUETOOTH=0 to use this sketch over USB.

OPTIONAL COMPUTER LOGGER
The old logger's columns are different: use the included updated Python file.
In Windows terminal, once: py -m pip install pyserial matplotlib
Set CSV_MODE=true in the Arduino sketch and upload.
CLOSE Arduino Serial Monitor and Serial Plotter before opening the logger.
From the extracted folder: py kynetix_fdc1004_logger.py COM3
Replace COM3 with your USB or outgoing Bluetooth COM port.
Press Enter to request re-zero; keep sensor unloaded. Ctrl+C or close graph
window to stop. CSV and whole-run PNG are saved in the terminal's working
folder. USB/Bluetooth port may reset the ESP32 when opened: startup baseline
requires the sensor to be unloaded.
CSV columns on device: time_s,cap_pF,delta_pF,capdac,errors,status
Logger also records host receive time and re-zero request events. Use
 device_time_s for timing analysis; host timestamps include transport delays.
Re-zero event markers show when requested, not when baseline completed.
Invalid samples are logged but not plotted as valid measurements.
Do not use the old ticks columns: CPU charge timing no longer exists.

MEASUREMENT AND ERRORS
FDC1004 uses a signed 24-bit result and its factory gain calibration.
The sketch adds CAPDAC offset to obtain nominal total pF, including wiring.
CAPDAC auto-adjusts on baseline collection, then remains fixed during recording.
Baseline collection normally takes less than a second; readings pause during it.
Re-zero establishes an unloaded reference, not a known-force calibration.
OK: all conversions successful. PARTIAL: some failed but valid average exists.
NO_DEVICE: I2C identity check failed. Check power and SDA/SCL; send b to retry.
NO_BASELINE: reference is invalid. Unload sensor and send b to retry.
READ_ERROR: communication/conversion timeout; no numeric measurement.
RANGE: residual capacitance is near/outside the +/-15 pF operating window.
Do not interpret NaN / RANGE / READ_ERROR as zero force. If RANGE occurs under
load, unload and re-zero; if it repeats, sensor/wiring capacitance change
exceeds available headroom. CAPDAC cannot compensate arbitrary capacitance.
Zero and negative changes are valid readings, not errors.
This update does not yet calculate force, normal/shear components, or contact
time. Those require mechanical calibration and contact thresholds.

VALIDATION
Host C++ checks with simulated Arduino/I2C APIs passed for signed decoding,
register configuration, baseline, CAPDAC selection/range, load changes, timeouts
and absent hardware. Python syntax and parser checks passed. An actual ESP32
board compilation/upload and physical sensor test were not available here.

REFERENCES
TI FDC1004 datasheet: https://www.ti.com/lit/ds/symlink/fdc1004.pdf
ESP32 setup: https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html
